/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 6;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.58398335933437, "KoPercent": 0.4160166406656266};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8777446966877559, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9832214765100671, 500, 1500, "S103_PegaTaskTracker_T01_HomePage"], "isController": true}, {"data": [1.0, 500, 1500, "25 \/prweb\/"], "isController": false}, {"data": [0.9369369369369369, 500, 1500, "88 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!TABTHREAD0"], "isController": false}, {"data": [1.0, 500, 1500, "108 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.2894736842105263, 500, 1500, "S102_PegaTest_T02_Login"], "isController": true}, {"data": [0.9363636363636364, 500, 1500, "S102_PegaTest_T03_Logout"], "isController": true}, {"data": [0.9137931034482759, 500, 1500, "56 \/prweb\/4nkyhN427tnQ2M8u7-kgHfJ4q6kBQpSp*\/!TABTHREAD0"], "isController": false}, {"data": [0.9966442953020134, 500, 1500, "4 \/prweb\/"], "isController": false}, {"data": [1.0, 500, 1500, "87 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!STANDARD"], "isController": false}, {"data": [1.0, 500, 1500, "55 \/prweb\/4nkyhN427tnQ2M8u7-kgHfJ4q6kBQpSp*\/!STANDARD"], "isController": false}, {"data": [0.9965034965034965, 500, 1500, "82 \/prweb\/4nkyhN427tnQ2M8u7-kgHfJ4q6kBQpSp*\/!STANDARD"], "isController": false}, {"data": [0.5087719298245614, 500, 1500, "42 \/prweb\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*\/!STANDARD"], "isController": false}, {"data": [0.963302752293578, 500, 1500, "109 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!STANDARD"], "isController": false}, {"data": [0.9953703703703703, 500, 1500, "103 \/prweb\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*\/!STANDARD"], "isController": false}, {"data": [1.0, 500, 1500, "44 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!STANDARD"], "isController": false}, {"data": [0.991304347826087, 500, 1500, "S102_PegaTest_T01_HomePage"], "isController": true}, {"data": [0.47278911564625853, 500, 1500, "S103_PegaTaskTracker_T02_Login"], "isController": true}, {"data": [1.0, 500, 1500, "88 \/prweb\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*\/!STANDARD"], "isController": false}, {"data": [0.9965277777777778, 500, 1500, "78 \/prweb\/4nkyhN427tnQ2M8u7-kgHfJ4q6kBQpSp*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.9722222222222222, 500, 1500, "S103_PegaTaskTracker_T03_Logout"], "isController": true}, {"data": [0.4965986394557823, 500, 1500, "11 \/prweb\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*\/!STANDARD"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1923, 8, 0.4160166406656266, 440.3317732709306, 0, 58960, 720.0, 766.8, 1127.8399999999997, 0.949271484733661, 8.891120349378062, 1.924243631816194], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["S103_PegaTaskTracker_T01_HomePage", 149, 0, 0.0, 284.2751677852349, 74, 13847, 160.0, 177.0, 11681.5, 0.07303552810813964, 0.5678122662495472, 0.127728404674911], "isController": true}, {"data": ["25 \/prweb\/", 115, 0, 0.0, 115.99130434782612, 76, 253, 158.0, 164.39999999999998, 250.28000000000006, 0.056788272579757895, 0.4416069417614043, 0.09920924722330038], "isController": false}, {"data": ["88 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!TABTHREAD0", 111, 4, 3.6036036036036037, 390.864864864865, 0, 1379, 457.2, 509.99999999999983, 1281.9199999999964, 0.05652237675066605, 1.1389668670664987, 0.19136273636283088], "isController": false}, {"data": ["108 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 110, 0, 0.0, 117.7181818181818, 91, 181, 137.8, 148.34999999999997, 179.46, 0.056471651231082, 0.1461590012282584, 0.19691480288826826], "isController": false}, {"data": ["S102_PegaTest_T02_Login", 114, 4, 3.508771929824561, 2515.7982456140357, 664, 58960, 1630.5, 2001.25, 55875.39999999988, 0.05628220489981027, 3.2826580579578346, 0.5307891740191468], "isController": true}, {"data": ["S102_PegaTest_T03_Logout", 110, 4, 3.6363636363636362, 772.4727272727273, 176, 30034, 470.8, 495.5999999999999, 27850.39000000001, 0.05603102692647405, 0.7572152562107846, 0.5075722590131], "isController": true}, {"data": ["56 \/prweb\/4nkyhN427tnQ2M8u7-kgHfJ4q6kBQpSp*\/!TABTHREAD0", 145, 0, 0.0, 450.0689655172414, 344, 638, 536.0, 562.8, 632.9399999999999, 0.07326644023125921, 1.445686312799445, 0.071845817376829], "isController": false}, {"data": ["4 \/prweb\/", 149, 0, 0.0, 128.986577181208, 74, 1091, 160.0, 171.0, 672.0, 0.0735778488207298, 0.5720285204593332, 0.12867684389669276], "isController": false}, {"data": ["87 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!STANDARD", 112, 0, 0.0, 94.03571428571428, 71, 147, 114.10000000000001, 130.39999999999998, 146.61, 0.056611345924640184, 0.07719002034217515, 0.11982228112638382], "isController": false}, {"data": ["55 \/prweb\/4nkyhN427tnQ2M8u7-kgHfJ4q6kBQpSp*\/!STANDARD", 146, 0, 0.0, 82.27397260273972, 61, 129, 101.30000000000001, 115.65, 127.12, 0.0732302358615487, 0.03955306577630069, 0.05600616149674577], "isController": false}, {"data": ["82 \/prweb\/4nkyhN427tnQ2M8u7-kgHfJ4q6kBQpSp*\/!STANDARD", 143, 0, 0.0, 167.11188811188802, 116, 1143, 189.6, 209.19999999999993, 787.0400000000018, 0.07340195475051806, 0.15949155207021745, 0.17147691550228752], "isController": false}, {"data": ["42 \/prweb\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*\/!STANDARD", 114, 0, 0.0, 746.8070175438597, 493, 1093, 819.0, 839.0, 1059.6999999999987, 0.05670211543655406, 1.063092776473795, 0.1308603765741676], "isController": false}, {"data": ["109 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!STANDARD", 109, 4, 3.669724770642202, 168.01834862385323, 0, 404, 201.0, 212.0, 393.50000000000057, 0.0563869906418288, 0.18458939342600114, 0.22553280694698072], "isController": false}, {"data": ["103 \/prweb\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*\/!STANDARD", 108, 0, 0.0, 130.74074074074073, 79, 1136, 165.20000000000002, 179.2, 1050.5899999999967, 0.05643562028233486, 0.4415768856943541, 0.09245394846853061], "isController": false}, {"data": ["44 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!STANDARD", 113, 0, 0.0, 230.07964601769913, 87, 400, 280.6, 296.7, 390.76, 0.056672539546649775, 1.0643644811002095, 0.09988515504202544], "isController": false}, {"data": ["S102_PegaTest_T01_HomePage", 115, 0, 0.0, 148.73913043478262, 76, 3903, 158.4, 167.5999999999999, 3319.0000000000123, 0.056369702902255424, 0.43835198670116166, 0.09847800500146316], "isController": true}, {"data": ["S103_PegaTaskTracker_T02_Login", 147, 0, 0.0, 1837.1020408163267, 1100, 42372, 1400.8000000000002, 1535.3999999999999, 36448.80000000013, 0.07257538953729487, 2.9632501462616267, 0.3049286851141458], "isController": true}, {"data": ["88 \/prweb\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*\/!STANDARD", 142, 0, 0.0, 92.28873239436622, 70, 137, 107.70000000000002, 113.0, 136.57, 0.07346850503492082, 0.5175081316571132, 0.03519422718634769], "isController": false}, {"data": ["78 \/prweb\/4nkyhN427tnQ2M8u7-kgHfJ4q6kBQpSp*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 144, 0, 0.0, 110.7986111111111, 83, 641, 129.5, 144.0, 431.3000000000053, 0.07335411699981662, 0.11535951715543942, 0.1453571205707358], "isController": false}, {"data": ["S103_PegaTaskTracker_T03_Logout", 144, 0, 0.0, 943.2152777777778, 297, 42970, 407.0, 441.5, 35632.75000000019, 0.07279024732002991, 0.7771460706914618, 0.3474917828214511], "isController": true}, {"data": ["11 \/prweb\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*\/!STANDARD", 147, 0, 0.0, 749.0476190476188, 648, 1712, 805.4000000000001, 830.0, 1419.2000000000062, 0.07311683124585609, 1.5230288213678718, 0.18094093916455814], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 366: https:\\\/\\\/icmsstg.moj.gov.local\\\/prweb\\\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*%5B%5B*\\\/!TABTHREAD0?pyActivity=%40baseclass.doUIAction&amp;action=display&amp;harnessName=pyDashboard7&amp;className=Data-Portal&amp;contentID=88d0292e-17d9-4ddd-9c1a-7e474fd0068c&amp;dynamicContainerID=f9e64470-c4fa-4e63-b814-0a50f75d0647&amp;tabIndex=1&amp;portalThreadName=STANDARD&amp;portalName=pyCaseManager7&amp;pzHarnessID=NO pzHarnessID", 4, 50.0, 0.2080083203328133], "isController": false}, {"data": ["Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 154: https:\\\/\\\/icmsstg.moj.gov.local\\\/prweb\\\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*%5B%5B*\\\/!STANDARD?pyActivity=LogOff&amp;pzPrimaryPageName=pyDisplayHarness&amp;pzHarnessID=NO pzHarnessID", 4, 50.0, 0.2080083203328133], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1923, 8, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 366: https:\\\/\\\/icmsstg.moj.gov.local\\\/prweb\\\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*%5B%5B*\\\/!TABTHREAD0?pyActivity=%40baseclass.doUIAction&amp;action=display&amp;harnessName=pyDashboard7&amp;className=Data-Portal&amp;contentID=88d0292e-17d9-4ddd-9c1a-7e474fd0068c&amp;dynamicContainerID=f9e64470-c4fa-4e63-b814-0a50f75d0647&amp;tabIndex=1&amp;portalThreadName=STANDARD&amp;portalName=pyCaseManager7&amp;pzHarnessID=NO pzHarnessID", 4, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 154: https:\\\/\\\/icmsstg.moj.gov.local\\\/prweb\\\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*%5B%5B*\\\/!STANDARD?pyActivity=LogOff&amp;pzPrimaryPageName=pyDisplayHarness&amp;pzHarnessID=NO pzHarnessID", 4, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["88 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!TABTHREAD0", 111, 4, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 366: https:\\\/\\\/icmsstg.moj.gov.local\\\/prweb\\\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*%5B%5B*\\\/!TABTHREAD0?pyActivity=%40baseclass.doUIAction&amp;action=display&amp;harnessName=pyDashboard7&amp;className=Data-Portal&amp;contentID=88d0292e-17d9-4ddd-9c1a-7e474fd0068c&amp;dynamicContainerID=f9e64470-c4fa-4e63-b814-0a50f75d0647&amp;tabIndex=1&amp;portalThreadName=STANDARD&amp;portalName=pyCaseManager7&amp;pzHarnessID=NO pzHarnessID", 4, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["109 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!STANDARD", 109, 4, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 154: https:\\\/\\\/icmsstg.moj.gov.local\\\/prweb\\\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*%5B%5B*\\\/!STANDARD?pyActivity=LogOff&amp;pzPrimaryPageName=pyDisplayHarness&amp;pzHarnessID=NO pzHarnessID", 4, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
