/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 6;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7908654757841241, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.985480943738657, 500, 1500, "366 \/prweb\/p_loginURL%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [3.4818941504178273E-4, 500, 1500, "111 \/prweb\/sJz4q7ugfgSxRrrdfjkitr-oF3eqH0KG*\/!STANDARD"], "isController": false}, {"data": [0.0, 500, 1500, "357 \/prweb\/p_loginURL%5B*\/!TABTHREAD0"], "isController": false}, {"data": [0.9990974729241877, 500, 1500, "356 \/prweb\/p_loginURL%5B*\/!STANDARD"], "isController": false}, {"data": [0.9664246823956443, 500, 1500, "370 \/prweb\/wPnkzmKNqOMVOdYA78l0keYXaXjzZutNzmr9BRMsnFQ%5B*\/!STANDARD"], "isController": false}, {"data": [0.9972047519217331, 500, 1500, "128 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.9973021582733813, 500, 1500, "S01_LoginManager_T01_HomePage"], "isController": true}, {"data": [0.9981851179673321, 500, 1500, "367 \/prweb\/wPnkzmKNqOMVOdYA78l0keYXaXjzZutNzmr9BRMsnFQ%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.9990763546798029, 500, 1500, "204 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.8871418588399721, 500, 1500, "S17_LoginAsJudge_T03_Logout"], "isController": true}, {"data": [0.9936479128856625, 500, 1500, "371 \/prweb\/sJz4q7ugfgSxRrrdfjkitr-oF3eqH0KG*\/!STANDARD"], "isController": false}, {"data": [0.9965181058495822, 500, 1500, "104 \/prweb\/"], "isController": false}, {"data": [0.0, 500, 1500, "S02_LoginAsClerk_T02_Login"], "isController": true}, {"data": [0.9804332634521313, 500, 1500, "129 \/prweb\/PRPushServlet\/!@7be12a6f7babe3503a1c92e0e5ce4d46!"], "isController": false}, {"data": [0.9975541579315165, 500, 1500, "155 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pyActivity=pzCancelFunctionalTestCase&pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&pzHarnessID=HID407EFB9677033BAFDD6B62C1E56FE252"], "isController": false}, {"data": [0.0, 500, 1500, "158 \/prweb\/p_HomeRedirectURL*\/!STANDARD"], "isController": false}, {"data": [0.5810621942697415, 500, 1500, "127 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0"], "isController": false}, {"data": [0.9821538461538462, 500, 1500, "205 \/prweb\/PRPushServlet\/!@c8f591ea4464927e19ca43999e191501!"], "isController": false}, {"data": [0.920923076923077, 500, 1500, "203 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0"], "isController": false}, {"data": [0.9965181058495822, 500, 1500, "S17_LoginAsJudge_T01_HomePage"], "isController": true}, {"data": [0.9870719776380154, 500, 1500, "146 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.9975369458128078, 500, 1500, "243 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pyActivity=pzCancelFunctionalTestCase&pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&pzHarnessID=HIDF02D58DBC70AE17CC8B4D4F02D81E406"], "isController": false}, {"data": [0.5118798043326345, 500, 1500, "143 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.9989517819706499, 500, 1500, "126 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!STANDARD"], "isController": false}, {"data": [0.9986023759608665, 500, 1500, "154 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.39981949458483756, 500, 1500, "363 \/prweb\/p_loginURL%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.9973021582733813, 500, 1500, "332 \/prweb\/"], "isController": false}, {"data": [0.8796182266009852, 500, 1500, "S02_LoginAsClerk_T03_Logout"], "isController": true}, {"data": [0.0, 500, 1500, "364 \/prweb\/p_loginURL%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.9676724137931034, 500, 1500, "244 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!STANDARD"], "isController": false}, {"data": [0.9898399014778325, 500, 1500, "229 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.0, 500, 1500, "345 \/prweb\/p_HomeRedirectURL*\/!STANDARD"], "isController": false}, {"data": [0.0, 500, 1500, "S01_LoginManager_T02_Login"], "isController": true}, {"data": [0.999384236453202, 500, 1500, "228 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0"], "isController": false}, {"data": [0.9969306322897483, 500, 1500, "146 \/prweb\/"], "isController": false}, {"data": [0.9990974729241877, 500, 1500, "358 \/prweb\/p_loginURL%5B*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.9969306322897483, 500, 1500, "S02_LoginAsClerk_T01_HomePage"], "isController": true}, {"data": [0.9987692307692307, 500, 1500, "202 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!STANDARD"], "isController": false}, {"data": [0.9612159329140462, 500, 1500, "156 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!STANDARD"], "isController": false}, {"data": [0.0, 500, 1500, "S17_LoginAsJudge_T02_Login"], "isController": true}, {"data": [0.5127041742286751, 500, 1500, "S01_LoginManager_T03_Logout"], "isController": true}, {"data": [0.9954627949183303, 500, 1500, "369 \/prweb\/wPnkzmKNqOMVOdYA78l0keYXaXjzZutNzmr9BRMsnFQ%5B*\/!TABTHREAD0?pyActivity=pzCancelFunctionalTestCase&pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&pzHarnessID=HID77A99FCD2DB2663A2907DAEC93922BFF"], "isController": false}, {"data": [0.9889162561576355, 500, 1500, "240 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.9984605911330049, 500, 1500, "242 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 41902, 0, 0.0, 679.6287050737446, 5, 23666, 3302.7000000000044, 4025.9500000000007, 5118.900000000016, 21.455526710599752, 147.0399460901217, 35.8408823324219], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["366 \/prweb\/p_loginURL%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 551, 0, 0.0, 249.3593466424682, 77, 1223, 378.6, 455.5999999999999, 622.9600000000005, 0.285607358821328, 1.0474561199410954, 0.6801742004030641], "isController": false}, {"data": ["111 \/prweb\/sJz4q7ugfgSxRrrdfjkitr-oF3eqH0KG*\/!STANDARD", 1436, 0, 0.0, 3926.2116991643397, 1465, 17333, 4483.3, 4662.699999999997, 5054.5199999999995, 0.7357597693116444, 7.0532598879567505, 1.6645259844629672], "isController": false}, {"data": ["357 \/prweb\/p_loginURL%5B*\/!TABTHREAD0", 554, 0, 0.0, 5778.705776173278, 2889, 23666, 9471.5, 10585.25, 11810.500000000004, 0.28504687323132016, 11.161679666195448, 0.3022186440399992], "isController": false}, {"data": ["356 \/prweb\/p_loginURL%5B*\/!STANDARD", 554, 0, 0.0, 40.409747292418764, 5, 1105, 81.0, 131.5, 221.70000000000118, 0.285866728312055, 0.7405849822055702, 0.21487120307451216], "isController": false}, {"data": ["370 \/prweb\/wPnkzmKNqOMVOdYA78l0keYXaXjzZutNzmr9BRMsnFQ%5B*\/!STANDARD", 551, 0, 0.0, 319.8566243194193, 143, 1536, 456.8, 522.5999999999999, 835.4000000000001, 0.2856107638455131, 1.638078140688182, 0.6489006050892105], "isController": false}, {"data": ["128 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 1431, 0, 0.0, 44.059399021663125, 21, 3028, 57.59999999999991, 98.39999999999986, 230.88000000000102, 0.7374528656305223, 4.9914367046356976, 1.360960027645464], "isController": false}, {"data": ["S01_LoginManager_T01_HomePage", 556, 0, 0.0, 151.00719424460414, 93, 1151, 204.3, 278.0, 440.32999999999845, 0.28554334121658925, 1.648918708417109, 0.29454531090713937], "isController": true}, {"data": ["367 \/prweb\/wPnkzmKNqOMVOdYA78l0keYXaXjzZutNzmr9BRMsnFQ%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 551, 0, 0.0, 47.143375680580746, 12, 1164, 89.80000000000001, 110.39999999999998, 204.2800000000002, 0.2856572579495408, 0.7966238024169403, 0.6286850345212389], "isController": false}, {"data": ["204 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 1624, 0, 0.0, 48.63793103448267, 23, 1069, 85.5, 117.75, 216.0, 0.8357697083915088, 6.092113335248639, 1.5317301639143048], "isController": false}, {"data": ["S17_LoginAsJudge_T03_Logout", 1431, 0, 0.0, 430.00349406009786, 211, 2353, 603.8, 688.0, 1320.0400000000002, 0.7372735305406931, 12.786842766018697, 4.0623789444584695], "isController": true}, {"data": ["371 \/prweb\/sJz4q7ugfgSxRrrdfjkitr-oF3eqH0KG*\/!STANDARD", 551, 0, 0.0, 161.27767695099809, 94, 3123, 213.8, 270.79999999999995, 1148.3200000000002, 0.28576644531436385, 1.676366247073617, 0.665858143086008], "isController": false}, {"data": ["104 \/prweb\/", 1436, 0, 0.0, 163.38022284122582, 93, 13792, 212.0, 283.4499999999996, 401.25999999999976, 0.7370588682142849, 4.256597368184002, 0.7609185065229196], "isController": false}, {"data": ["S02_LoginAsClerk_T02_Login", 1628, 0, 0.0, 5150.729115479117, 3289, 19123, 5802.200000000001, 6048.55, 6618.1, 0.8342386291430095, 41.51878978550894, 10.179077226002828], "isController": true}, {"data": ["129 \/prweb\/PRPushServlet\/!@7be12a6f7babe3503a1c92e0e5ce4d46!", 1431, 0, 0.0, 235.0489168413695, 100, 1752, 377.0, 466.0, 789.0400000000018, 0.7374752886512294, 1.765907624778139, 0.6336087903601518], "isController": false}, {"data": ["155 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pyActivity=pzCancelFunctionalTestCase&pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&pzHarnessID=HID407EFB9677033BAFDD6B62C1E56FE252", 1431, 0, 0.0, 85.06429070580006, 27, 1134, 124.0, 172.39999999999986, 311.0, 0.7374505853997152, 6.527435446179506, 0.8698022069664602], "isController": false}, {"data": ["158 \/prweb\/p_HomeRedirectURL*\/!STANDARD", 1628, 0, 0.0, 3938.6136363636388, 2249, 17285, 4493.200000000001, 4653.599999999999, 5134.370000000002, 0.834247606534393, 10.30808671550363, 1.8876691666978398], "isController": false}, {"data": ["127 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0", 1431, 0, 0.0, 647.337526205449, 248, 2004, 851.0, 930.5999999999995, 1085.560000000001, 0.7373696463408225, 6.301817217961263, 0.7552128219293527], "isController": false}, {"data": ["205 \/prweb\/PRPushServlet\/!@c8f591ea4464927e19ca43999e191501!", 1625, 0, 0.0, 233.02523076923086, 106, 1871, 382.0, 462.7999999999993, 842.2400000000007, 0.8355877061137766, 2.000840874405254, 0.7104971131408894], "isController": false}, {"data": ["203 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0", 1625, 0, 0.0, 396.9649230769235, 100, 1445, 550.0, 618.0, 740.48, 0.8355434528871754, 7.564198981202586, 0.8059268519627815], "isController": false}, {"data": ["S17_LoginAsJudge_T01_HomePage", 1436, 0, 0.0, 163.38022284122582, 93, 13792, 212.0, 283.4499999999996, 401.25999999999976, 0.7370539501934253, 4.256568966063695, 0.760913429298767], "isController": true}, {"data": ["146 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 1431, 0, 0.0, 257.57651991614216, 97, 3429, 392.0, 449.39999999999986, 580.0, 0.7373008811028908, 3.918457138171267, 1.6832486775856925], "isController": false}, {"data": ["243 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pyActivity=pzCancelFunctionalTestCase&pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&pzHarnessID=HIDF02D58DBC70AE17CC8B4D4F02D81E406", 1624, 0, 0.0, 98.34605911330064, 29, 1295, 161.5, 212.75, 374.25, 0.8356316634421439, 7.779708898107222, 0.9357631876337834], "isController": false}, {"data": ["143 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 1431, 0, 0.0, 846.5457721872802, 207, 2129, 1078.6, 1154.0, 1276.0400000000002, 0.7372112396121991, 5.841566346564498, 1.6139304734714717], "isController": false}, {"data": ["126 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!STANDARD", 1431, 0, 0.0, 18.74004192872116, 5, 1079, 22.0, 30.0, 204.76000000000045, 0.7375201387836638, 1.8804417114603207, 0.5335347268070274], "isController": false}, {"data": ["154 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 1431, 0, 0.0, 27.532494758909866, 12, 1068, 32.0, 56.0, 161.68000000000006, 0.7374669273654342, 2.032984739079202, 1.5597563611675993], "isController": false}, {"data": ["363 \/prweb\/p_loginURL%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 554, 0, 0.0, 1522.799638989169, 444, 6389, 3271.5, 4986.25, 5823.650000000002, 0.28565344256225983, 2.898352511333326, 0.9704093011970633], "isController": false}, {"data": ["332 \/prweb\/", 556, 0, 0.0, 151.00719424460414, 93, 1151, 204.3, 278.0, 440.32999999999845, 0.28554876720996253, 1.6489500417409642, 0.2945509079590556], "isController": false}, {"data": ["S02_LoginAsClerk_T03_Logout", 1624, 0, 0.0, 433.2167487684729, 231, 1678, 606.5, 661.75, 1375.75, 0.8355190250357308, 14.85474735758748, 4.508835218181594], "isController": true}, {"data": ["364 \/prweb\/p_loginURL%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 553, 0, 0.0, 4841.546112115729, 2573, 16529, 8137.2, 9605.8, 10230.780000000002, 0.2849377181795932, 8.410103264965027, 1.0358690069044583], "isController": false}, {"data": ["244 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!STANDARD", 1624, 0, 0.0, 304.3965517241377, 140, 1349, 457.0, 518.75, 726.75, 0.8355495461844352, 4.7921703952550665, 1.7547818683175973], "isController": false}, {"data": ["229 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 1624, 0, 0.0, 238.1354679802957, 80, 1624, 359.0, 426.75, 575.5, 0.8357021853817985, 4.8467325601201265, 1.8751910031693901], "isController": false}, {"data": ["345 \/prweb\/p_HomeRedirectURL*\/!STANDARD", 556, 0, 0.0, 3964.7949640287743, 2190, 17374, 4552.7, 4723.9, 5096.699999999995, 0.2849340116402718, 3.557513818947241, 0.6504035799127159], "isController": false}, {"data": ["S01_LoginManager_T02_Login", 556, 0, 0.0, 16419.406474820134, 4429, 41278, 26510.800000000003, 29534.899999999998, 31621.759999999987, 0.28472520944714147, 29.75937543208075, 4.361909653676079], "isController": true}, {"data": ["228 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0", 1624, 0, 0.0, 19.384236453201975, 5, 1054, 26.0, 46.5, 156.0, 0.8357748698347544, 2.1211458150529023, 0.8330840681316057], "isController": false}, {"data": ["146 \/prweb\/", 1629, 0, 0.0, 151.9821976672803, 92, 1233, 211.0, 272.5, 419.60000000000036, 0.8353871858067256, 4.824481991995873, 0.8625121691079563], "isController": false}, {"data": ["358 \/prweb\/p_loginURL%5B*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 554, 0, 0.0, 75.9386281588448, 23, 1047, 157.5, 194.0, 265.2500000000002, 0.2858530106668579, 2.104498664965824, 0.5367246825625536], "isController": false}, {"data": ["S02_LoginAsClerk_T01_HomePage", 1629, 0, 0.0, 152.00122774708385, 92, 1233, 211.0, 272.5, 419.60000000000036, 0.8353683364119058, 4.824373134010722, 0.8624927076741581], "isController": true}, {"data": ["202 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!STANDARD", 1625, 0, 0.0, 20.470769230769253, 5, 1058, 24.0, 46.099999999999454, 189.0, 0.8356349720177988, 2.1207908383488574, 0.5979224338871322], "isController": false}, {"data": ["156 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!STANDARD", 1431, 0, 0.0, 317.4067085953874, 143, 1391, 472.0, 539.0, 704.8000000000006, 0.7373468498131127, 4.228943407180089, 1.6336006851696414], "isController": false}, {"data": ["S17_LoginAsJudge_T02_Login", 1436, 0, 0.0, 5968.4630919220035, 3526, 19225, 6701.2, 6985.0, 7851.829999999995, 0.7357522298006296, 31.613241337779186, 8.207857546250944], "isController": true}, {"data": ["S01_LoginManager_T03_Logout", 551, 0, 0.0, 733.3121597096185, 402, 3767, 937.2, 1052.1999999999994, 1865.8000000000002, 0.28556754086958686, 5.855715720493125, 2.6659835215284757], "isController": true}, {"data": ["369 \/prweb\/wPnkzmKNqOMVOdYA78l0keYXaXjzZutNzmr9BRMsnFQ%5B*\/!TABTHREAD0?pyActivity=pzCancelFunctionalTestCase&pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&pzHarnessID=HID77A99FCD2DB2663A2907DAEC93922BFF", 551, 0, 0.0, 205.0344827586207, 105, 1260, 300.20000000000005, 372.9999999999999, 505.9200000000005, 0.2856954714416007, 1.7470947677415074, 0.7236228844729956], "isController": false}, {"data": ["240 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 1624, 0, 0.0, 257.9685960591138, 84, 13803, 374.5, 440.0, 573.75, 0.8356342433033487, 6.5878178820646855, 1.9705162919733832], "isController": false}, {"data": ["242 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 1624, 0, 0.0, 30.474137931034512, 12, 1095, 35.0, 62.75, 184.5, 0.835692724430324, 2.284566623338263, 1.818858448048112], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 41902, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
