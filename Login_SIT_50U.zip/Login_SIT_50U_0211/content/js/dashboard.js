/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 6;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.70713135158881, "KoPercent": 0.2928686484111876};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8516264919260472, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9730941704035875, 500, 1500, "366 \/prweb\/p_loginURL%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.47244094488188976, 500, 1500, "111 \/prweb\/sJz4q7ugfgSxRrrdfjkitr-oF3eqH0KG*\/!STANDARD"], "isController": false}, {"data": [0.32751091703056767, 500, 1500, "357 \/prweb\/p_loginURL%5B*\/!TABTHREAD0"], "isController": false}, {"data": [1.0, 500, 1500, "356 \/prweb\/p_loginURL%5B*\/!STANDARD"], "isController": false}, {"data": [0.9681818181818181, 500, 1500, "370 \/prweb\/wPnkzmKNqOMVOdYA78l0keYXaXjzZutNzmr9BRMsnFQ%5B*\/!STANDARD"], "isController": false}, {"data": [0.9917355371900827, 500, 1500, "128 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.997907949790795, 500, 1500, "S01_LoginManager_T01_HomePage"], "isController": true}, {"data": [0.9659090909090909, 500, 1500, "367 \/prweb\/wPnkzmKNqOMVOdYA78l0keYXaXjzZutNzmr9BRMsnFQ%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.9681818181818181, 500, 1500, "204 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.9208333333333333, 500, 1500, "S17_LoginAsJudge_T03_Logout"], "isController": true}, {"data": [0.9954545454545455, 500, 1500, "371 \/prweb\/sJz4q7ugfgSxRrrdfjkitr-oF3eqH0KG*\/!STANDARD"], "isController": false}, {"data": [0.9883720930232558, 500, 1500, "104 \/prweb\/"], "isController": false}, {"data": [0.3404255319148936, 500, 1500, "S02_LoginAsClerk_T02_Login"], "isController": true}, {"data": [0.9838709677419355, 500, 1500, "129 \/prweb\/PRPushServlet\/!@7be12a6f7babe3503a1c92e0e5ce4d46!"], "isController": false}, {"data": [0.975, 500, 1500, "155 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pyActivity=pzCancelFunctionalTestCase&pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&pzHarnessID=HID407EFB9677033BAFDD6B62C1E56FE252"], "isController": false}, {"data": [0.46170212765957447, 500, 1500, "158 \/prweb\/p_HomeRedirectURL*\/!STANDARD"], "isController": false}, {"data": [0.9715447154471545, 500, 1500, "127 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0"], "isController": false}, {"data": [0.9646017699115044, 500, 1500, "205 \/prweb\/PRPushServlet\/!@c8f591ea4464927e19ca43999e191501!"], "isController": false}, {"data": [0.9446902654867256, 500, 1500, "203 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0"], "isController": false}, {"data": [0.9728682170542635, 500, 1500, "S17_LoginAsJudge_T01_HomePage"], "isController": true}, {"data": [0.9916666666666667, 500, 1500, "146 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.9931818181818182, 500, 1500, "243 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pyActivity=pzCancelFunctionalTestCase&pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&pzHarnessID=HIDF02D58DBC70AE17CC8B4D4F02D81E406"], "isController": false}, {"data": [0.9958333333333333, 500, 1500, "143 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.9920634920634921, 500, 1500, "126 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!STANDARD"], "isController": false}, {"data": [0.975, 500, 1500, "154 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.875, 500, 1500, "363 \/prweb\/p_loginURL%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.997907949790795, 500, 1500, "332 \/prweb\/"], "isController": false}, {"data": [0.9340909090909091, 500, 1500, "S02_LoginAsClerk_T03_Logout"], "isController": true}, {"data": [0.38392857142857145, 500, 1500, "364 \/prweb\/p_loginURL%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.9454545454545454, 500, 1500, "244 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!STANDARD"], "isController": false}, {"data": [0.48326359832635984, 500, 1500, "345 \/prweb\/p_HomeRedirectURL*\/!STANDARD"], "isController": false}, {"data": [0.9681818181818181, 500, 1500, "229 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.0, 500, 1500, "S01_LoginManager_T02_Login"], "isController": true}, {"data": [0.975, 500, 1500, "228 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0"], "isController": false}, {"data": [0.9978991596638656, 500, 1500, "146 \/prweb\/"], "isController": false}, {"data": [0.989451476793249, 500, 1500, "358 \/prweb\/p_loginURL%5B*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.9873949579831933, 500, 1500, "S02_LoginAsClerk_T01_HomePage"], "isController": true}, {"data": [0.9849137931034483, 500, 1500, "202 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!STANDARD"], "isController": false}, {"data": [0.9541666666666667, 500, 1500, "156 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!STANDARD"], "isController": false}, {"data": [0.3700787401574803, 500, 1500, "S17_LoginAsJudge_T02_Login"], "isController": true}, {"data": [0.9204545454545454, 500, 1500, "S01_LoginManager_T03_Logout"], "isController": true}, {"data": [0.9977272727272727, 500, 1500, "369 \/prweb\/wPnkzmKNqOMVOdYA78l0keYXaXjzZutNzmr9BRMsnFQ%5B*\/!TABTHREAD0?pyActivity=pzCancelFunctionalTestCase&pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&pzHarnessID=HID77A99FCD2DB2663A2907DAEC93922BFF"], "isController": false}, {"data": [0.9818181818181818, 500, 1500, "240 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [1.0, 500, 1500, "242 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 6829, 20, 0.2928686484111876, 668.16298140284, 0, 96537, 834.0, 1369.0, 16290.299999999967, 3.261407883256021, 26.634670764330686, 5.916844352066809], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["366 \/prweb\/p_loginURL%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 223, 0, 0.0, 289.61434977578483, 48, 18916, 136.1999999999999, 232.39999999999944, 12871.319999999976, 0.11259384924541925, 0.41431017964525363, 0.2684542241942976], "isController": false}, {"data": ["111 \/prweb\/sJz4q7ugfgSxRrrdfjkitr-oF3eqH0KG*\/!STANDARD", 127, 0, 0.0, 1010.4251968503934, 518, 22007, 1053.8000000000002, 1607.1999999999994, 19366.31999999999, 0.061265169159403284, 0.5831261839976343, 0.13771990562631334], "isController": false}, {"data": ["357 \/prweb\/p_loginURL%5B*\/!TABTHREAD0", 229, 1, 0.4366812227074236, 1713.7292576419213, 0, 23474, 2481.0, 3252.0, 17195.299999999952, 0.11264717919657474, 4.385031736282869, 0.11877970977118357], "isController": false}, {"data": ["356 \/prweb\/p_loginURL%5B*\/!STANDARD", 237, 0, 0.0, 17.20675105485234, 7, 241, 27.200000000000017, 33.0, 118.98000000000013, 0.11517075887325094, 0.29782248602157435, 0.08677527843259887], "isController": false}, {"data": ["370 \/prweb\/wPnkzmKNqOMVOdYA78l0keYXaXjzZutNzmr9BRMsnFQ%5B*\/!STANDARD", 220, 1, 0.45454545454545453, 356.8954545454546, 0, 15821, 204.20000000000005, 251.0, 11777.829999999925, 0.11452791852275644, 0.6548263886900557, 0.2587325382341044], "isController": false}, {"data": ["128 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 121, 0, 0.0, 49.198347107438025, 23, 1030, 34.8, 100.29999999999994, 1029.56, 0.06023283725037596, 0.4059946210147391, 0.11110679518495711], "isController": false}, {"data": ["S01_LoginManager_T01_HomePage", 239, 0, 0.0, 108.06276150627619, 93, 1099, 107.0, 141.0, 374.1999999999982, 0.11471869679560441, 0.661776544718452, 0.11733382333776689], "isController": true}, {"data": ["367 \/prweb\/wPnkzmKNqOMVOdYA78l0keYXaXjzZutNzmr9BRMsnFQ%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 220, 0, 0.0, 325.20454545454544, 14, 16347, 36.900000000000006, 98.29999999999961, 15559.169999999991, 0.11453292691497752, 0.321224492833883, 0.25239492173366407], "isController": false}, {"data": ["204 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 220, 0, 0.0, 257.5136363636363, 26, 18201, 64.9, 143.5999999999999, 10981.259999999971, 0.1143496907100752, 0.8328584193598184, 0.21100634533580606], "isController": false}, {"data": ["S17_LoginAsJudge_T03_Logout", 120, 2, 1.6666666666666667, 1338.066666666667, 169, 36201, 368.20000000000005, 12618.049999999888, 33700.529999999904, 0.060626545029608486, 1.045683076598861, 0.33138169538091405], "isController": true}, {"data": ["371 \/prweb\/sJz4q7ugfgSxRrrdfjkitr-oF3eqH0KG*\/!STANDARD", 220, 0, 0.0, 112.09090909090902, 93, 1100, 107.80000000000001, 166.5499999999999, 912.9799999999932, 0.11458918215617254, 0.6722073655973065, 0.2668674625058987], "isController": false}, {"data": ["104 \/prweb\/", 129, 0, 0.0, 257.44961240310096, 92, 17814, 170.0, 219.0, 12799.19999999981, 0.061862878292699645, 0.3568608015103174, 0.06342190749749312], "isController": false}, {"data": ["S02_LoginAsClerk_T02_Login", 235, 4, 1.702127659574468, 4574.936170212766, 419, 51011, 17275.0, 20157.59999999999, 48611.719999999994, 0.11255053399241649, 5.350897654865943, 1.3159123690522432], "isController": true}, {"data": ["129 \/prweb\/PRPushServlet\/!@7be12a6f7babe3503a1c92e0e5ce4d46!", 124, 2, 1.6129032258064515, 138.41129032258067, 0, 372, 206.5, 265.5, 358.25, 0.06080279300571743, 0.14464989053045532, 0.051325341525365546], "isController": false}, {"data": ["155 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pyActivity=pzCancelFunctionalTestCase&pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&pzHarnessID=HID407EFB9677033BAFDD6B62C1E56FE252", 120, 0, 0.0, 222.26666666666665, 27, 15777, 65.50000000000003, 88.94999999999999, 13131.8399999999, 0.06175511113604188, 0.5428142596990262, 0.07269593771019252], "isController": false}, {"data": ["158 \/prweb\/p_HomeRedirectURL*\/!STANDARD", 235, 0, 0.0, 1185.5063829787237, 69, 19550, 1410.6, 2048.7999999999906, 17868.119999999995, 0.11336561278455372, 1.3890853796529952, 0.25484226064418686], "isController": false}, {"data": ["127 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0", 123, 2, 1.6260162601626016, 147.21138211382117, 0, 1180, 214.00000000000034, 372.7999999999998, 1127.4400000000012, 0.06073882109404938, 0.5119721486271545, 0.061124129132461985], "isController": false}, {"data": ["205 \/prweb\/PRPushServlet\/!@c8f591ea4464927e19ca43999e191501!", 226, 4, 1.7699115044247788, 329.51327433628313, 0, 18858, 220.80000000000018, 360.89999999999895, 12563.829999999953, 0.11087214185354674, 0.2636413667640641, 0.09248479739342538], "isController": false}, {"data": ["203 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0", 226, 4, 1.7699115044247788, 327.18141592920364, 0, 18655, 265.50000000000006, 557.7999999999979, 12138.10999999995, 0.1116097884747584, 0.9955038130978038, 0.10562669667867047], "isController": false}, {"data": ["S17_LoginAsJudge_T01_HomePage", 129, 0, 0.0, 336.9844961240312, 92, 17814, 170.0, 226.5, 14099.099999999858, 0.061421200884465295, 0.3543129511958565, 0.0629690992140467], "isController": true}, {"data": ["146 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 120, 0, 0.0, 224.79166666666666, 54, 17822, 114.10000000000005, 198.74999999999994, 14138.17999999986, 0.061754125947539866, 0.32792858087088755, 0.14083337997056386], "isController": false}, {"data": ["243 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pyActivity=pzCancelFunctionalTestCase&pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&pzHarnessID=HIDF02D58DBC70AE17CC8B4D4F02D81E406", 220, 0, 0.0, 51.50909090909091, 28, 1038, 47.0, 51.94999999999999, 905.7399999999968, 0.1143495124032837, 1.0618454708627048, 0.1304096090494125], "isController": false}, {"data": ["143 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 120, 0, 0.0, 172.88333333333335, 103, 1147, 235.80000000000007, 269.95, 984.6699999999938, 0.06175136123156915, 0.48562963006560567, 0.13503788478173723], "isController": false}, {"data": ["126 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!STANDARD", 126, 0, 0.0, 141.88888888888886, 8, 16158, 16.0, 48.39999999999969, 11817.750000000064, 0.06134073316781072, 0.1546097971739448, 0.04433777262548075], "isController": false}, {"data": ["154 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 120, 0, 0.0, 323.6583333333333, 15, 20896, 28.80000000000001, 94.89999999999998, 19107.009999999933, 0.061755651414050025, 0.1726575036075593, 0.13046785985018078], "isController": false}, {"data": ["363 \/prweb\/p_loginURL%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 224, 0, 0.0, 591.7946428571427, 179, 13259, 789.0, 1140.0, 11361.0, 0.11218639769977817, 1.1354431794676856, 0.3813557906148566], "isController": false}, {"data": ["332 \/prweb\/", 239, 0, 0.0, 108.06276150627619, 93, 1099, 107.0, 141.0, 374.1999999999982, 0.11472161528034314, 0.6617933805507982, 0.1173368083522616], "isController": false}, {"data": ["S02_LoginAsClerk_T03_Logout", 220, 4, 1.8181818181818181, 907.1545454545452, 169, 41213, 448.5000000000001, 639.1499999999996, 36373.80999999984, 0.11199240080654892, 1.983164296924434, 0.6039640609068126], "isController": true}, {"data": ["364 \/prweb\/p_loginURL%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 224, 0, 0.0, 1458.0178571428573, 105, 24103, 2056.5, 2553.25, 14947.25, 0.11202649426589388, 3.2935660377429263, 0.40750506635444284], "isController": false}, {"data": ["244 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!STANDARD", 220, 4, 1.8181818181818181, 469.8318181818182, 0, 20630, 341.5000000000002, 474.5999999999997, 18389.81999999999, 0.11462189882637595, 0.6479597106630668, 0.23606168403535774], "isController": false}, {"data": ["345 \/prweb\/p_HomeRedirectURL*\/!STANDARD", 239, 0, 0.0, 1102.2343096234304, 536, 22946, 923.0, 1155.0, 22023.6, 0.11502445593191707, 1.4318682647225287, 0.2618256773989939], "isController": false}, {"data": ["229 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 220, 0, 0.0, 288.37727272727255, 48, 18800, 134.70000000000013, 184.95, 12490.24999999996, 0.1143472538987216, 0.6604416795870401, 0.2584604258122813], "isController": false}, {"data": ["S01_LoginManager_T02_Login", 239, 1, 0.41841004184100417, 9040.468619246863, 2377, 96537, 23709.0, 39022.0, 95489.0, 0.11414903565557367, 11.424068193571213, 1.6799949247858155], "isController": true}, {"data": ["228 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0", 220, 0, 0.0, 217.24999999999983, 7, 17208, 20.900000000000006, 50.499999999999886, 12038.039999999957, 0.11435117662162962, 0.28993972296088466, 0.11574909539123177], "isController": false}, {"data": ["146 \/prweb\/", 238, 0, 0.0, 105.55462184873949, 71, 513, 107.29999999999998, 144.2999999999999, 383.2999999999966, 0.11411978165721103, 0.6619188020072135, 0.11691433776003009], "isController": false}, {"data": ["358 \/prweb\/p_loginURL%5B*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 237, 0, 0.0, 159.97046413502116, 25, 17158, 48.400000000000034, 84.89999999999995, 7028.260000000044, 0.11593930650683675, 0.8529565845515521, 0.2179274676421712], "isController": false}, {"data": ["S02_LoginAsClerk_T01_HomePage", 238, 0, 0.0, 220.82773109243698, 71, 10486, 107.29999999999998, 144.2999999999999, 9374.19999999996, 0.11330549255516263, 0.6571957534779549, 0.116080108411457], "isController": true}, {"data": ["202 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!STANDARD", 232, 0, 0.0, 194.87068965517236, 7, 18452, 22.700000000000017, 53.89999999999992, 11953.279999999933, 0.11293544035816112, 0.28619251899457276, 0.0820370667684546], "isController": false}, {"data": ["156 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!STANDARD", 120, 2, 1.6666666666666667, 497.5583333333333, 0, 22930, 268.0000000000001, 391.54999999999967, 20853.729999999923, 0.06203916532506972, 0.35128667613280934, 0.13500586722481236], "isController": false}, {"data": ["S17_LoginAsJudge_T02_Login", 127, 2, 1.5748031496062993, 3869.779527559056, 976, 68845, 2899.8000000000047, 21359.599999999995, 65149.83999999998, 0.060824686968382655, 2.5166490181782004, 0.653407965004732], "isController": true}, {"data": ["S01_LoginManager_T03_Logout", 220, 1, 0.45454545454545453, 1181.0409090909084, 345, 59424, 507.30000000000007, 1441.6499999999996, 19859.549999999996, 0.11109708370155283, 2.2778482435929805, 1.0358658944577706], "isController": true}, {"data": ["369 \/prweb\/wPnkzmKNqOMVOdYA78l0keYXaXjzZutNzmr9BRMsnFQ%5B*\/!TABTHREAD0?pyActivity=pzCancelFunctionalTestCase&pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&pzHarnessID=HID77A99FCD2DB2663A2907DAEC93922BFF", 220, 0, 0.0, 118.94090909090907, 94, 1136, 116.0, 147.79999999999995, 266.73999999999995, 0.11453215177800755, 0.7003324856977976, 0.2900244073872197], "isController": false}, {"data": ["240 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 220, 0, 0.0, 134.44545454545445, 35, 4289, 109.9, 179.84999999999997, 3332.849999999996, 0.11434737276515856, 0.8944875007601502, 0.27154354042595436], "isController": false}, {"data": ["242 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 220, 0, 0.0, 20.87727272727272, 15, 123, 22.0, 27.899999999999977, 105.10999999999993, 0.11435093887318584, 0.31664266325675633, 0.2507685430767783], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 130: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/No%20loginURL%5B*\\\/!STANDARD?pyActivity=LogOff&amp;pzPrimaryPageName=pyDisplayHarness&amp;pzHarnessID=NO pzHarnessID 2", 1, 5.0, 0.014643432420559379], "isController": false}, {"data": ["Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 145: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/sJz4q7ugfgSxRrrdfjkitr-oF3eqH0KG*\\\/!TABTHREAD0?pyActivity=%40baseclass.doUIAction&amp;action=display&amp;harnessName=NO harnessName&amp;className=Data-Portal&amp;model=NO model&amp;contentID=NO contentID&amp;dynamicContainerID=NO dynamicContainerID&amp;tabIndex=1&amp;portalThreadName=STANDARD&amp;portalName=NO portalName&amp;pzHarnessID=NO pzHarnessID", 2, 10.0, 0.029286864841118757], "isController": false}, {"data": ["Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 113: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/PRPushServlet\\\/!@7be12a6f7babe3503a1c92e0e5ce4d46!?PZSRVRPSH=true&amp;portalName=NO portalName&amp;X-Atmosphere-tracking-id=0&amp;X-Atmosphere-Framework=2.3.1-javascript&amp;X-Atmosphere-Transport=long-polling&amp;X-Atmosphere-TrackMessageSize=true&amp;Content-Type=application%2Fjson&amp;X-atmo-protocol=true&amp;_=1571485052525", 2, 10.0, 0.029286864841118757], "isController": false}, {"data": ["Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 146: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/sJz4q7ugfgSxRrrdfjkitr-oF3eqH0KG*\\\/!STANDARD?pyActivity=LogOff&amp;pzPrimaryPageName=pyDisplayHarness&amp;pzHarnessID=NO pzHarnessID 2", 2, 10.0, 0.029286864841118757], "isController": false}, {"data": ["Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 132: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/No%20loginURL%5B%5B*\\\/!TABTHREAD0?pyActivity=%40baseclass.doUIAction&amp;action=display&amp;harnessName=NO harnessName&amp;className=Data-Portal&amp;contentID=NO contentID&amp;dynamicContainerID=NO dynamicContainerID&amp;tabIndex=1&amp;portalThreadName=STANDARD&amp;portalName=NO portalName&amp;pzHarnessID=NO pzHarnessID", 4, 20.0, 0.058573729682237514], "isController": false}, {"data": ["Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 133: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/No%20loginURL%5B%5B*\\\/!STANDARD?pyActivity=LogOff&amp;pzPrimaryPageName=pyDisplayHarness&amp;pzHarnessID=NO pzHarnessID 2", 4, 20.0, 0.058573729682237514], "isController": false}, {"data": ["Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 129: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/No%20loginURL%5B*\\\/!TABTHREAD0?pyActivity=%40baseclass.doUIAction&amp;action=display&amp;harnessName=NO harnessName&amp;className=Data-Portal&amp;model=NO model&amp;contentID=NO contentID&amp;dynamicContainerID=NO dynamicContainerID&amp;tabIndex=1&amp;portalThreadName=STANDARD&amp;portalName=NO portalName&amp;pzHarnessID=NO pzHarnessID", 1, 5.0, 0.014643432420559379], "isController": false}, {"data": ["Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 113: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/PRPushServlet\\\/!@c8f591ea4464927e19ca43999e191501!?PZSRVRPSH=true&amp;portalName=NO portalName&amp;X-Atmosphere-tracking-id=0&amp;X-Atmosphere-Framework=2.3.1-javascript&amp;X-Atmosphere-Transport=long-polling&amp;X-Atmosphere-TrackMessageSize=true&amp;Content-Type=application%2Fjson&amp;X-atmo-protocol=true&amp;_=1569920310102", 4, 20.0, 0.058573729682237514], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 6829, 20, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 132: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/No%20loginURL%5B%5B*\\\/!TABTHREAD0?pyActivity=%40baseclass.doUIAction&amp;action=display&amp;harnessName=NO harnessName&amp;className=Data-Portal&amp;contentID=NO contentID&amp;dynamicContainerID=NO dynamicContainerID&amp;tabIndex=1&amp;portalThreadName=STANDARD&amp;portalName=NO portalName&amp;pzHarnessID=NO pzHarnessID", 4, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 133: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/No%20loginURL%5B%5B*\\\/!STANDARD?pyActivity=LogOff&amp;pzPrimaryPageName=pyDisplayHarness&amp;pzHarnessID=NO pzHarnessID 2", 4, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 113: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/PRPushServlet\\\/!@c8f591ea4464927e19ca43999e191501!?PZSRVRPSH=true&amp;portalName=NO portalName&amp;X-Atmosphere-tracking-id=0&amp;X-Atmosphere-Framework=2.3.1-javascript&amp;X-Atmosphere-Transport=long-polling&amp;X-Atmosphere-TrackMessageSize=true&amp;Content-Type=application%2Fjson&amp;X-atmo-protocol=true&amp;_=1569920310102", 4, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 145: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/sJz4q7ugfgSxRrrdfjkitr-oF3eqH0KG*\\\/!TABTHREAD0?pyActivity=%40baseclass.doUIAction&amp;action=display&amp;harnessName=NO harnessName&amp;className=Data-Portal&amp;model=NO model&amp;contentID=NO contentID&amp;dynamicContainerID=NO dynamicContainerID&amp;tabIndex=1&amp;portalThreadName=STANDARD&amp;portalName=NO portalName&amp;pzHarnessID=NO pzHarnessID", 2, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 113: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/PRPushServlet\\\/!@7be12a6f7babe3503a1c92e0e5ce4d46!?PZSRVRPSH=true&amp;portalName=NO portalName&amp;X-Atmosphere-tracking-id=0&amp;X-Atmosphere-Framework=2.3.1-javascript&amp;X-Atmosphere-Transport=long-polling&amp;X-Atmosphere-TrackMessageSize=true&amp;Content-Type=application%2Fjson&amp;X-atmo-protocol=true&amp;_=1571485052525", 2], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["357 \/prweb\/p_loginURL%5B*\/!TABTHREAD0", 229, 1, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 129: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/No%20loginURL%5B*\\\/!TABTHREAD0?pyActivity=%40baseclass.doUIAction&amp;action=display&amp;harnessName=NO harnessName&amp;className=Data-Portal&amp;model=NO model&amp;contentID=NO contentID&amp;dynamicContainerID=NO dynamicContainerID&amp;tabIndex=1&amp;portalThreadName=STANDARD&amp;portalName=NO portalName&amp;pzHarnessID=NO pzHarnessID", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["370 \/prweb\/wPnkzmKNqOMVOdYA78l0keYXaXjzZutNzmr9BRMsnFQ%5B*\/!STANDARD", 220, 1, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 130: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/No%20loginURL%5B*\\\/!STANDARD?pyActivity=LogOff&amp;pzPrimaryPageName=pyDisplayHarness&amp;pzHarnessID=NO pzHarnessID 2", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["129 \/prweb\/PRPushServlet\/!@7be12a6f7babe3503a1c92e0e5ce4d46!", 124, 2, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 113: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/PRPushServlet\\\/!@7be12a6f7babe3503a1c92e0e5ce4d46!?PZSRVRPSH=true&amp;portalName=NO portalName&amp;X-Atmosphere-tracking-id=0&amp;X-Atmosphere-Framework=2.3.1-javascript&amp;X-Atmosphere-Transport=long-polling&amp;X-Atmosphere-TrackMessageSize=true&amp;Content-Type=application%2Fjson&amp;X-atmo-protocol=true&amp;_=1571485052525", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["127 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0", 123, 2, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 145: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/sJz4q7ugfgSxRrrdfjkitr-oF3eqH0KG*\\\/!TABTHREAD0?pyActivity=%40baseclass.doUIAction&amp;action=display&amp;harnessName=NO harnessName&amp;className=Data-Portal&amp;model=NO model&amp;contentID=NO contentID&amp;dynamicContainerID=NO dynamicContainerID&amp;tabIndex=1&amp;portalThreadName=STANDARD&amp;portalName=NO portalName&amp;pzHarnessID=NO pzHarnessID", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["205 \/prweb\/PRPushServlet\/!@c8f591ea4464927e19ca43999e191501!", 226, 4, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 113: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/PRPushServlet\\\/!@c8f591ea4464927e19ca43999e191501!?PZSRVRPSH=true&amp;portalName=NO portalName&amp;X-Atmosphere-tracking-id=0&amp;X-Atmosphere-Framework=2.3.1-javascript&amp;X-Atmosphere-Transport=long-polling&amp;X-Atmosphere-TrackMessageSize=true&amp;Content-Type=application%2Fjson&amp;X-atmo-protocol=true&amp;_=1569920310102", 4, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["203 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0", 226, 4, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 132: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/No%20loginURL%5B%5B*\\\/!TABTHREAD0?pyActivity=%40baseclass.doUIAction&amp;action=display&amp;harnessName=NO harnessName&amp;className=Data-Portal&amp;contentID=NO contentID&amp;dynamicContainerID=NO dynamicContainerID&amp;tabIndex=1&amp;portalThreadName=STANDARD&amp;portalName=NO portalName&amp;pzHarnessID=NO pzHarnessID", 4, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["244 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!STANDARD", 220, 4, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 133: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/No%20loginURL%5B%5B*\\\/!STANDARD?pyActivity=LogOff&amp;pzPrimaryPageName=pyDisplayHarness&amp;pzHarnessID=NO pzHarnessID 2", 4, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["156 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!STANDARD", 120, 2, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 146: http:\\\/\\\/icmstst.moj.gov.local\\\/prweb\\\/sJz4q7ugfgSxRrrdfjkitr-oF3eqH0KG*\\\/!STANDARD?pyActivity=LogOff&amp;pzPrimaryPageName=pyDisplayHarness&amp;pzHarnessID=NO pzHarnessID 2", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
