/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 6;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8541841004184101, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9807692307692307, 500, 1500, "366 \/prweb\/p_loginURL%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.475, 500, 1500, "111 \/prweb\/sJz4q7ugfgSxRrrdfjkitr-oF3eqH0KG*\/!STANDARD"], "isController": false}, {"data": [0.34545454545454546, 500, 1500, "357 \/prweb\/p_loginURL%5B*\/!TABTHREAD0"], "isController": false}, {"data": [1.0, 500, 1500, "356 \/prweb\/p_loginURL%5B*\/!STANDARD"], "isController": false}, {"data": [0.97, 500, 1500, "370 \/prweb\/wPnkzmKNqOMVOdYA78l0keYXaXjzZutNzmr9BRMsnFQ%5B*\/!STANDARD"], "isController": false}, {"data": [1.0, 500, 1500, "128 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.9454545454545454, 500, 1500, "S01_LoginManager_T01_HomePage"], "isController": true}, {"data": [0.98, 500, 1500, "367 \/prweb\/wPnkzmKNqOMVOdYA78l0keYXaXjzZutNzmr9BRMsnFQ%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [1.0, 500, 1500, "204 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.9636363636363636, 500, 1500, "S17_LoginAsJudge_T03_Logout"], "isController": true}, {"data": [0.97, 500, 1500, "371 \/prweb\/sJz4q7ugfgSxRrrdfjkitr-oF3eqH0KG*\/!STANDARD"], "isController": false}, {"data": [0.9833333333333333, 500, 1500, "104 \/prweb\/"], "isController": false}, {"data": [0.36363636363636365, 500, 1500, "S02_LoginAsClerk_T02_Login"], "isController": true}, {"data": [0.9655172413793104, 500, 1500, "129 \/prweb\/PRPushServlet\/!@7be12a6f7babe3503a1c92e0e5ce4d46!"], "isController": false}, {"data": [0.9818181818181818, 500, 1500, "155 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pyActivity=pzCancelFunctionalTestCase&pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&pzHarnessID=HID407EFB9677033BAFDD6B62C1E56FE252"], "isController": false}, {"data": [0.4636363636363636, 500, 1500, "158 \/prweb\/p_HomeRedirectURL*\/!STANDARD"], "isController": false}, {"data": [0.9655172413793104, 500, 1500, "127 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0"], "isController": false}, {"data": [0.9818181818181818, 500, 1500, "205 \/prweb\/PRPushServlet\/!@c8f591ea4464927e19ca43999e191501!"], "isController": false}, {"data": [0.9537037037037037, 500, 1500, "203 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0"], "isController": false}, {"data": [0.9833333333333333, 500, 1500, "S17_LoginAsJudge_T01_HomePage"], "isController": true}, {"data": [0.9636363636363636, 500, 1500, "146 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.98, 500, 1500, "243 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pyActivity=pzCancelFunctionalTestCase&pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&pzHarnessID=HIDF02D58DBC70AE17CC8B4D4F02D81E406"], "isController": false}, {"data": [0.9196428571428571, 500, 1500, "143 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [1.0, 500, 1500, "126 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!STANDARD"], "isController": false}, {"data": [1.0, 500, 1500, "154 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.8636363636363636, 500, 1500, "363 \/prweb\/p_loginURL%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.9454545454545454, 500, 1500, "332 \/prweb\/"], "isController": false}, {"data": [0.92, 500, 1500, "S02_LoginAsClerk_T03_Logout"], "isController": true}, {"data": [0.4230769230769231, 500, 1500, "364 \/prweb\/p_loginURL%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.97, 500, 1500, "244 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!STANDARD"], "isController": false}, {"data": [0.4727272727272727, 500, 1500, "345 \/prweb\/p_HomeRedirectURL*\/!STANDARD"], "isController": false}, {"data": [0.9807692307692307, 500, 1500, "229 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.0, 500, 1500, "S01_LoginManager_T02_Login"], "isController": true}, {"data": [1.0, 500, 1500, "228 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0"], "isController": false}, {"data": [0.990909090909091, 500, 1500, "146 \/prweb\/"], "isController": false}, {"data": [0.9727272727272728, 500, 1500, "358 \/prweb\/p_loginURL%5B*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.990909090909091, 500, 1500, "S02_LoginAsClerk_T01_HomePage"], "isController": true}, {"data": [1.0, 500, 1500, "202 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!STANDARD"], "isController": false}, {"data": [0.9818181818181818, 500, 1500, "156 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!STANDARD"], "isController": false}, {"data": [0.30833333333333335, 500, 1500, "S17_LoginAsJudge_T02_Login"], "isController": true}, {"data": [0.83, 500, 1500, "S01_LoginManager_T03_Logout"], "isController": true}, {"data": [0.97, 500, 1500, "369 \/prweb\/wPnkzmKNqOMVOdYA78l0keYXaXjzZutNzmr9BRMsnFQ%5B*\/!TABTHREAD0?pyActivity=pzCancelFunctionalTestCase&pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&pzHarnessID=HID77A99FCD2DB2663A2907DAEC93922BFF"], "isController": false}, {"data": [0.9705882352941176, 500, 1500, "240 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.98, 500, 1500, "242 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1910, 0, 0.0, 943.3486910994774, 8, 108888, 776.7000000000003, 1233.649999999997, 23400.81999999918, 0.9842874737823952, 7.932925547316657, 1.778824931943736], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["366 \/prweb\/p_loginURL%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 52, 0, 0.0, 299.28846153846143, 50, 11722, 155.20000000000022, 269.5999999999999, 11722.0, 0.028397501675179546, 0.10415101590014346, 0.06759499220297442], "isController": false}, {"data": ["111 \/prweb\/sJz4q7ugfgSxRrrdfjkitr-oF3eqH0KG*\/!STANDARD", 60, 0, 0.0, 1047.1166666666666, 560, 17671, 1080.3, 1789.099999999997, 17671.0, 0.03145127175838294, 0.30117766502351245, 0.07101568163686048], "isController": false}, {"data": ["357 \/prweb\/p_loginURL%5B*\/!TABTHREAD0", 55, 0, 0.0, 1971.818181818181, 686, 25599, 2494.199999999999, 7266.399999999993, 25599.0, 0.02933097121245169, 1.152045763581173, 0.031065727340091543], "isController": false}, {"data": ["356 \/prweb\/p_loginURL%5B*\/!STANDARD", 55, 0, 0.0, 16.909090909090907, 8, 177, 20.4, 32.19999999999991, 177.0, 0.02934801516705424, 0.07603856039047802, 0.022027165289889024], "isController": false}, {"data": ["370 \/prweb\/wPnkzmKNqOMVOdYA78l0keYXaXjzZutNzmr9BRMsnFQ%5B*\/!STANDARD", 50, 0, 0.0, 482.56000000000006, 124, 14945, 301.0, 626.9499999999979, 14945.0, 0.029501623179307327, 0.1692021805977265, 0.0669456364739188], "isController": false}, {"data": ["128 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 58, 0, 0.0, 39.36206896551723, 27, 164, 56.300000000000004, 71.5999999999998, 164.0, 0.031199234005013395, 0.2112246766777657, 0.057522011765607686], "isController": false}, {"data": ["S01_LoginManager_T01_HomePage", 55, 0, 0.0, 261.4545454545455, 99, 3797, 146.19999999999993, 2034.7999999999943, 3797.0, 0.029345462791287063, 0.16926788072403262, 0.0299967736664488], "isController": true}, {"data": ["367 \/prweb\/wPnkzmKNqOMVOdYA78l0keYXaXjzZutNzmr9BRMsnFQ%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 50, 0, 0.0, 223.7199999999999, 16, 10169, 23.0, 27.449999999999996, 10169.0, 0.029504338908079825, 0.08228598769610058, 0.06489744420877035], "isController": false}, {"data": ["204 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 52, 0, 0.0, 42.71153846153847, 30, 183, 49.7, 107.79999999999995, 183.0, 0.028306791180257102, 0.20636292946709742, 0.05184776236857075], "isController": false}, {"data": ["S17_LoginAsJudge_T03_Logout", 55, 0, 0.0, 379.9818181818182, 181, 4865, 404.2, 926.99999999999, 4865.0, 0.03159639341531161, 0.5479696534593742, 0.17384916869170824], "isController": true}, {"data": ["371 \/prweb\/sJz4q7ugfgSxRrrdfjkitr-oF3eqH0KG*\/!STANDARD", 50, 0, 0.0, 378.15999999999985, 98, 13262, 121.5, 341.6999999999987, 13262.0, 0.029501988729060225, 0.17306488896041483, 0.06874193858157979], "isController": false}, {"data": ["104 \/prweb\/", 60, 0, 0.0, 151.16666666666669, 97, 2612, 118.9, 176.14999999999984, 2612.0, 0.03146143064563575, 0.18149210390189907, 0.032188566575271214], "isController": false}, {"data": ["S02_LoginAsClerk_T02_Login", 55, 0, 0.0, 8991.6, 1008, 106483, 35025.199999999975, 66797.99999999984, 106483.0, 0.028420644135813473, 1.3713374590419762, 0.33387898547860106], "isController": true}, {"data": ["129 \/prweb\/PRPushServlet\/!@7be12a6f7babe3503a1c92e0e5ce4d46!", 58, 0, 0.0, 204.50000000000006, 98, 2023, 293.7, 1000.5499999999997, 2023.0, 0.03097418622001178, 0.07416865684713758, 0.02655638026180664], "isController": false}, {"data": ["155 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pyActivity=pzCancelFunctionalTestCase&pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&pzHarnessID=HID407EFB9677033BAFDD6B62C1E56FE252", 55, 0, 0.0, 117.27272727272727, 32, 4162, 51.599999999999994, 82.39999999999957, 4162.0, 0.03159900744644974, 0.2796714141302718, 0.03720906560442294], "isController": false}, {"data": ["158 \/prweb\/p_HomeRedirectURL*\/!STANDARD", 55, 0, 0.0, 1535.1454545454535, 575, 26407, 1232.5999999999997, 9781.799999999994, 26407.0, 0.029085063233571566, 0.35913649421868266, 0.06569960483975452], "isController": false}, {"data": ["127 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0", 58, 0, 0.0, 709.7413793103447, 101, 24109, 231.00000000000006, 771.2999999999752, 24109.0, 0.03097423584424018, 0.2647250991509321, 0.031668381653586285], "isController": false}, {"data": ["205 \/prweb\/PRPushServlet\/!@c8f591ea4464927e19ca43999e191501!", 55, 0, 0.0, 163.63636363636365, 101, 953, 220.79999999999998, 367.3999999999985, 953.0, 0.02910875347849604, 0.06970181985280498, 0.024721766626126112], "isController": false}, {"data": ["203 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0", 54, 0, 0.0, 337.4814814814814, 73, 8937, 355.0, 1477.0, 8937.0, 0.028809956721042793, 0.2607734566399481, 0.02775803067540142], "isController": false}, {"data": ["S17_LoginAsJudge_T01_HomePage", 60, 0, 0.0, 151.16666666666669, 97, 2612, 118.9, 176.14999999999984, 2612.0, 0.03146118319217749, 0.18149067641281685, 0.03218831340267378], "isController": true}, {"data": ["146 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 55, 0, 0.0, 226.58181818181814, 56, 5808, 149.3999999999999, 1379.4, 5808.0, 0.03159862620663663, 0.167978229587862, 0.07207819442720882], "isController": false}, {"data": ["243 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pyActivity=pzCancelFunctionalTestCase&pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&pzHarnessID=HIDF02D58DBC70AE17CC8B4D4F02D81E406", 50, 0, 0.0, 120.28, 34, 3756, 53.9, 104.94999999999953, 3756.0, 0.02925934075194165, 0.2724176062450552, 0.03272988716574129], "isController": false}, {"data": ["143 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 56, 0, 0.0, 405.5178571428573, 136, 4085, 590.5000000000011, 2634.1999999999975, 4085.0, 0.030364597482015754, 0.24029832047853522, 0.0664188503760059], "isController": false}, {"data": ["126 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!STANDARD", 60, 0, 0.0, 18.13333333333333, 8, 132, 26.0, 50.349999999999945, 132.0, 0.03150747514847897, 0.08033585655696815, 0.022736766368133342], "isController": false}, {"data": ["154 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 55, 0, 0.0, 30.472727272727276, 16, 226, 29.799999999999997, 171.19999999999987, 226.0, 0.03159949762544139, 0.08711350851951183, 0.06677245406438484], "isController": false}, {"data": ["363 \/prweb\/p_loginURL%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 55, 0, 0.0, 416.1636363636364, 210, 1724, 736.4, 1598.3999999999994, 1724.0, 0.029518298930203177, 0.29938955654659516, 0.10024586227244746], "isController": false}, {"data": ["332 \/prweb\/", 55, 0, 0.0, 261.4545454545455, 99, 3797, 146.19999999999993, 2034.7999999999943, 3797.0, 0.029346010810003258, 0.16927104175670557, 0.02999733384822243], "isController": false}, {"data": ["S02_LoginAsClerk_T03_Logout", 50, 0, 0.0, 460.3599999999999, 184, 3909, 506.0999999999998, 3605.5499999999993, 3909.0, 0.029257046559663893, 0.520185716417299, 0.15773319511816922], "isController": true}, {"data": ["364 \/prweb\/p_loginURL%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 52, 0, 0.0, 1118.25, 592, 4176, 1607.4, 1814.4, 4176.0, 0.02836037749844018, 0.8379887571896284, 0.10306787957501974], "isController": false}, {"data": ["244 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!STANDARD", 50, 0, 0.0, 250.64000000000016, 125, 3655, 251.69999999999996, 564.599999999999, 3655.0, 0.029257731355510692, 0.1678033752450335, 0.06136580575792153], "isController": false}, {"data": ["345 \/prweb\/p_HomeRedirectURL*\/!STANDARD", 55, 0, 0.0, 1506.690909090909, 561, 31072, 1205.6, 4242.799999999945, 31072.0, 0.02933794917066952, 0.36615500422066405, 0.06686104030367444], "isController": false}, {"data": ["229 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 52, 0, 0.0, 158.01923076923077, 56, 3960, 157.5, 221.49999999999983, 3960.0, 0.028429235532389373, 0.1648220808232232, 0.06376022751999204], "isController": false}, {"data": ["S01_LoginManager_T02_Login", 55, 0, 0.0, 12996.127272727272, 2205, 108888, 47733.599999999955, 83153.79999999987, 108888.0, 0.028345357777682722, 2.9270094877710395, 0.4265337165776021], "isController": true}, {"data": ["228 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0", 52, 0, 0.0, 14.153846153846153, 11, 22, 16.700000000000003, 18.349999999999994, 22.0, 0.02830743837824508, 0.07185309065511578, 0.028185698530952822], "isController": false}, {"data": ["146 \/prweb\/", 55, 0, 0.0, 140.56363636363636, 99, 1182, 141.79999999999993, 381.39999999999947, 1182.0, 0.02909374056106485, 0.16781591901043194, 0.0297394645614436], "isController": false}, {"data": ["358 \/prweb\/p_loginURL%5B*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 55, 0, 0.0, 102.00000000000001, 30, 2628, 72.19999999999996, 265.59999999999627, 2628.0, 0.029347936866718213, 0.2162117536352756, 0.05507219559119284], "isController": false}, {"data": ["S02_LoginAsClerk_T01_HomePage", 55, 0, 0.0, 140.56363636363636, 99, 1182, 141.79999999999993, 381.39999999999947, 1182.0, 0.02909363283200596, 0.16781529761728436, 0.02973935444138109], "isController": true}, {"data": ["202 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!STANDARD", 55, 0, 0.0, 15.290909090909091, 8, 108, 17.799999999999997, 23.399999999999928, 108.0, 0.029095125720038237, 0.07385212868536055, 0.020789169908128173], "isController": false}, {"data": ["156 \/prweb\/wPnkzmKNqONNXZgna6AB2m5AdvZEjcNj*\/!STANDARD", 55, 0, 0.0, 232.2363636363636, 127, 2734, 326.0, 407.39999999999964, 2734.0, 0.03159735547369606, 0.18122194208693063, 0.06987941425827793], "isController": false}, {"data": ["S17_LoginAsJudge_T02_Login", 60, 0, 0.0, 6989.950000000001, 1086, 87058, 25894.799999999996, 61147.69999999985, 87058.0, 0.031004547333608926, 1.2868713908769118, 0.3321044215391174], "isController": true}, {"data": ["S01_LoginManager_T03_Logout", 50, 0, 0.0, 1429.6599999999999, 362, 15185, 1388.5999999999997, 11896.949999999988, 15185.0, 0.029497411307183682, 0.6048663114637559, 0.2752724924766852], "isController": true}, {"data": ["369 \/prweb\/wPnkzmKNqOMVOdYA78l0keYXaXjzZutNzmr9BRMsnFQ%5B*\/!TABTHREAD0?pyActivity=pzCancelFunctionalTestCase&pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&pzHarnessID=HID77A99FCD2DB2663A2907DAEC93922BFF", 50, 0, 0.0, 345.22, 110, 10134, 182.7999999999999, 686.5499999999967, 10134.0, 0.029501814656619527, 0.18041051111303857, 0.0747340890813194], "isController": false}, {"data": ["240 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 51, 0, 0.0, 181.5686274509804, 65, 4146, 202.4000000000002, 457.39999999999964, 4146.0, 0.028112013696614046, 0.22161842016959812, 0.0662589569147561], "isController": false}, {"data": ["242 \/prweb\/wPnkzmKNqONCZWEUa4Rn_g%5B%5B*\/!TABTHREAD0?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 50, 0, 0.0, 89.44000000000001, 17, 3320, 30.9, 47.79999999999998, 3320.0, 0.02925985442637226, 0.07999769926107164, 0.0636476126372726], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1910, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
