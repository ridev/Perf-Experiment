/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 6;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.50708564386937, "KoPercent": 0.4929143561306223};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8830315742989623, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9925531914893617, 500, 1500, "S103_PegaTaskTracker_T01_HomePage"], "isController": true}, {"data": [0.9951690821256038, 500, 1500, "25 \/prweb\/"], "isController": false}, {"data": [0.9438902743142145, 500, 1500, "88 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!TABTHREAD0"], "isController": false}, {"data": [0.9962406015037594, 500, 1500, "108 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.41605839416058393, 500, 1500, "S102_PegaTest_T02_Login"], "isController": true}, {"data": [0.918546365914787, 500, 1500, "S102_PegaTest_T03_Logout"], "isController": true}, {"data": [0.9707158351409978, 500, 1500, "56 \/prweb\/4nkyhN427tnQ2M8u7-kgHfJ4q6kBQpSp*\/!TABTHREAD0"], "isController": false}, {"data": [0.997872340425532, 500, 1500, "4 \/prweb\/"], "isController": false}, {"data": [0.9987593052109182, 500, 1500, "87 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!STANDARD"], "isController": false}, {"data": [0.9956896551724138, 500, 1500, "55 \/prweb\/4nkyhN427tnQ2M8u7-kgHfJ4q6kBQpSp*\/!STANDARD"], "isController": false}, {"data": [0.995575221238938, 500, 1500, "82 \/prweb\/4nkyhN427tnQ2M8u7-kgHfJ4q6kBQpSp*\/!STANDARD"], "isController": false}, {"data": [0.5097323600973236, 500, 1500, "42 \/prweb\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*\/!STANDARD"], "isController": false}, {"data": [0.952020202020202, 500, 1500, "109 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!STANDARD"], "isController": false}, {"data": [0.9936386768447837, 500, 1500, "103 \/prweb\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*\/!STANDARD"], "isController": false}, {"data": [0.9926108374384236, 500, 1500, "44 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!STANDARD"], "isController": false}, {"data": [0.9879227053140096, 500, 1500, "S102_PegaTest_T01_HomePage"], "isController": true}, {"data": [0.47002141327623126, 500, 1500, "S103_PegaTaskTracker_T02_Login"], "isController": true}, {"data": [0.9911111111111112, 500, 1500, "88 \/prweb\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*\/!STANDARD"], "isController": false}, {"data": [0.9989010989010989, 500, 1500, "78 \/prweb\/4nkyhN427tnQ2M8u7-kgHfJ4q6kBQpSp*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1"], "isController": false}, {"data": [0.9626373626373627, 500, 1500, "S103_PegaTaskTracker_T03_Logout"], "isController": true}, {"data": [0.4892933618843683, 500, 1500, "11 \/prweb\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*\/!STANDARD"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 6492, 32, 0.4929143561306223, 427.2994454713495, 0, 54490, 694.0, 742.0, 1715.3499999999985, 3.11066730809406, 29.24488118360124, 6.408515349935697], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["S103_PegaTaskTracker_T01_HomePage", 470, 0, 0.0, 190.91702127659582, 71, 13425, 144.90000000000003, 157.0, 514.5100000000168, 0.22374282713819593, 1.7394810039661985, 0.39132215081361454], "isController": true}, {"data": ["25 \/prweb\/", 414, 0, 0.0, 114.91545893719811, 70, 1123, 142.5, 156.0, 966.8500000000178, 0.19853620312459538, 1.5438955669899033, 0.3468454668406176], "isController": false}, {"data": ["88 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!TABTHREAD0", 401, 16, 3.9900249376558605, 362.8753117206978, 0, 1584, 425.8, 458.9, 1303.600000000013, 0.19801295725685392, 3.975025341862458, 0.6676586410620112], "isController": false}, {"data": ["108 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 399, 0, 0.0, 110.26065162907273, 80, 1111, 114.0, 120.0, 329.0, 0.1986583837572126, 0.5181418063001096, 0.6927054899107431], "isController": false}, {"data": ["S102_PegaTest_T02_Login", 411, 16, 3.8929440389294405, 2069.2360097323603, 628, 54490, 1534.6, 2071.99999999999, 38044.99999999995, 0.19695330960628987, 11.437049917810329, 1.8526702201025114], "isController": true}, {"data": ["S102_PegaTest_T03_Logout", 399, 16, 4.010025062656641, 969.5764411027568, 161, 43558, 422.0, 1341.0, 30565.0, 0.19708258501223985, 2.671014195348604, 1.7838116607010905], "isController": true}, {"data": ["56 \/prweb\/4nkyhN427tnQ2M8u7-kgHfJ4q6kBQpSp*\/!TABTHREAD0", 461, 0, 0.0, 427.33405639913263, 292, 1840, 475.0, 497.9, 1603.2599999999993, 0.22590176948219, 4.456620930184838, 0.22143746462628203], "isController": false}, {"data": ["4 \/prweb\/", 470, 0, 0.0, 113.0234042553192, 71, 1096, 144.90000000000003, 157.0, 314.41000000000264, 0.2253556783877192, 1.7520200611804706, 0.39414299842682554], "isController": false}, {"data": ["87 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!STANDARD", 403, 0, 0.0, 87.03970223325062, 67, 1096, 95.0, 99.0, 122.63999999999982, 0.19766112447108483, 0.26951751863679546, 0.41841237821524263], "isController": false}, {"data": ["55 \/prweb\/4nkyhN427tnQ2M8u7-kgHfJ4q6kBQpSp*\/!STANDARD", 464, 0, 0.0, 81.76939655172406, 59, 1127, 86.0, 88.0, 457.50000000002115, 0.22589089372466334, 0.12192619970458923, 0.17267387148268648], "isController": false}, {"data": ["82 \/prweb\/4nkyhN427tnQ2M8u7-kgHfJ4q6kBQpSp*\/!STANDARD", 452, 0, 0.0, 159.31415929203536, 104, 1355, 166.7, 207.0999999999998, 735.8399999999772, 0.22491433848811784, 0.48870547181256074, 0.5253353002556659], "isController": false}, {"data": ["42 \/prweb\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*\/!STANDARD", 411, 0, 0.0, 734.3138686131392, 457, 2095, 776.8, 826.9999999999999, 2012.04, 0.19837908360447554, 3.7035150648340007, 0.45621004966234524], "isController": false}, {"data": ["109 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!STANDARD", 396, 16, 4.040404040404041, 164.39141414141417, 0, 1398, 173.0, 189.14999999999998, 1160.019999999999, 0.19855625534936125, 0.6483799128884571, 0.7911230695606241], "isController": false}, {"data": ["103 \/prweb\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*\/!STANDARD", 393, 0, 0.0, 124.87531806615776, 73, 1145, 150.0, 159.0, 1095.06, 0.19860682115885311, 1.553354448837013, 0.3245882517053402], "isController": false}, {"data": ["44 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!STANDARD", 406, 0, 0.0, 218.80788177339906, 75, 1230, 248.3, 259.65, 1016.8300000000008, 0.19757239008575908, 3.6956711474174706, 0.3483278832125757], "isController": false}, {"data": ["S102_PegaTest_T01_HomePage", 414, 0, 0.0, 156.9227053140097, 70, 8569, 143.0, 156.25, 1118.9500000000007, 0.19711422864774403, 1.5328377344302377, 0.3443612579482504], "isController": true}, {"data": ["S103_PegaTaskTracker_T02_Login", 467, 0, 0.0, 1903.3618843683098, 995, 47265, 1324.8, 2117.799999999999, 34603.51999999998, 0.22379233604695517, 9.136916174405393, 0.9401563733972732], "isController": true}, {"data": ["88 \/prweb\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*\/!STANDARD", 450, 0, 0.0, 104.30666666666669, 68, 1175, 98.0, 105.44999999999999, 1083.98, 0.22565756614775456, 1.5895195552966344, 0.10810407778265867], "isController": false}, {"data": ["78 \/prweb\/4nkyhN427tnQ2M8u7-kgHfJ4q6kBQpSp*\/!STANDARD?pzTransactionId=&pzFromFrame=&pzPrimaryPageName=pyDisplayHarness&AJAXTrackID=1", 455, 0, 0.0, 99.61758241758234, 73, 1095, 114.0, 130.2, 293.9999999999998, 0.2248274757952222, 0.35335629435401383, 0.4454259251527098], "isController": false}, {"data": ["S103_PegaTaskTracker_T03_Logout", 455, 0, 0.0, 950.2835164835163, 269, 45017, 386.80000000000007, 530.1999999999996, 33976.52, 0.2230654586814135, 2.386073644999902, 1.065204592084363], "isController": true}, {"data": ["11 \/prweb\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*\/!STANDARD", 467, 0, 0.0, 734.0042826552464, 604, 2000, 783.0, 845.0, 1786.84, 0.22541253631579378, 4.6923439787460595, 0.5576425250101725], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 366: https:\\\/\\\/icmsstg.moj.gov.local\\\/prweb\\\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*%5B%5B*\\\/!TABTHREAD0?pyActivity=%40baseclass.doUIAction&amp;action=display&amp;harnessName=pyDashboard7&amp;className=Data-Portal&amp;contentID=88d0292e-17d9-4ddd-9c1a-7e474fd0068c&amp;dynamicContainerID=f9e64470-c4fa-4e63-b814-0a50f75d0647&amp;tabIndex=1&amp;portalThreadName=STANDARD&amp;portalName=pyCaseManager7&amp;pzHarnessID=NO pzHarnessID", 16, 50.0, 0.24645717806531114], "isController": false}, {"data": ["Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 154: https:\\\/\\\/icmsstg.moj.gov.local\\\/prweb\\\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*%5B%5B*\\\/!STANDARD?pyActivity=LogOff&amp;pzPrimaryPageName=pyDisplayHarness&amp;pzHarnessID=NO pzHarnessID", 16, 50.0, 0.24645717806531114], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 6492, 32, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 366: https:\\\/\\\/icmsstg.moj.gov.local\\\/prweb\\\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*%5B%5B*\\\/!TABTHREAD0?pyActivity=%40baseclass.doUIAction&amp;action=display&amp;harnessName=pyDashboard7&amp;className=Data-Portal&amp;contentID=88d0292e-17d9-4ddd-9c1a-7e474fd0068c&amp;dynamicContainerID=f9e64470-c4fa-4e63-b814-0a50f75d0647&amp;tabIndex=1&amp;portalThreadName=STANDARD&amp;portalName=pyCaseManager7&amp;pzHarnessID=NO pzHarnessID", 16, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 154: https:\\\/\\\/icmsstg.moj.gov.local\\\/prweb\\\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*%5B%5B*\\\/!STANDARD?pyActivity=LogOff&amp;pzPrimaryPageName=pyDisplayHarness&amp;pzHarnessID=NO pzHarnessID", 16, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["88 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!TABTHREAD0", 401, 16, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 366: https:\\\/\\\/icmsstg.moj.gov.local\\\/prweb\\\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*%5B%5B*\\\/!TABTHREAD0?pyActivity=%40baseclass.doUIAction&amp;action=display&amp;harnessName=pyDashboard7&amp;className=Data-Portal&amp;contentID=88d0292e-17d9-4ddd-9c1a-7e474fd0068c&amp;dynamicContainerID=f9e64470-c4fa-4e63-b814-0a50f75d0647&amp;tabIndex=1&amp;portalThreadName=STANDARD&amp;portalName=pyCaseManager7&amp;pzHarnessID=NO pzHarnessID", 16, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["109 \/prweb\/EGD_mG2bYLJOo_r9qtJ4CQ%5B%5B*\/!STANDARD", 396, 16, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in query at index 154: https:\\\/\\\/icmsstg.moj.gov.local\\\/prweb\\\/beEBp4uRVTogorRwSwWqbOtn9IL2fwdI*%5B%5B*\\\/!STANDARD?pyActivity=LogOff&amp;pzPrimaryPageName=pyDisplayHarness&amp;pzHarnessID=NO pzHarnessID", 16, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
